import React from 'react'

const Content = () => {
  return (
    <main>Content</main>
  )
}

export default Content