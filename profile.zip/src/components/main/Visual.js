import React from "react";

const Visual = () => {
  return <div id="visual">Visual</div>;
};

export default Visual;
