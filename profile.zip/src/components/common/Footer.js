import React from "react";

const Footer = () => {
  return (
    <Footer>
      <div className="inner">
        <p>2023 Portfolio By Park Sieun. &copy All Right Reserved.</p>
      </div>
    </Footer>
  );
};

export default Footer;
