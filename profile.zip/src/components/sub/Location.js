import React from 'react'

const Location = () => {
  return (
    <div>Location</div>
  )
}

export default Location