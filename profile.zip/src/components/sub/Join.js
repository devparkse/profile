import React from 'react'

const Join = () => {
  return (
    <div>Join</div>
  )
}

export default Join