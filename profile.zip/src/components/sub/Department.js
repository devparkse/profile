import React from 'react'

const Department = () => {
  return (
    <div>Department</div>
  )
}

export default Department